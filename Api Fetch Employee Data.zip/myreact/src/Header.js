function Header() {
  return (
    <div>Use Effect Demo</div>
  )
}

export default Header