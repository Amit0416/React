import React from 'react'

function amit() {
  return (
    <div>
      amit   
    </div>
  )
}

export default amit