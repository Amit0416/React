const Movies = () => {


  function App(){
    let login = false;

    if (login == false) {
      return <h1>Hide</h1>
    }
  }

  
  return (
    <div className="move">
          <img src= "https://images-na.ssl-images-amazon.com/images/M/MV5BMTgxNTAyNTU0NV5BMl5BanBnXkFtZTgwNzMzMDY3OTE@._V1_.jpg" alt="" /> 
          <p>Dr.</p>
          <p>year:2016</p>
    </div>
  );
}

export default Movies